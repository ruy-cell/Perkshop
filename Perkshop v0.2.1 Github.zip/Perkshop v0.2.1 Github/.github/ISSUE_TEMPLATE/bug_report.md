---
name: Bug report
about: Report a PerkShop issue
title: "[Bug]: "
labels: bug
assignees: ""
---

## Environment

- V Rising server version:
- BepInEx version:
- VampireCommandFramework version:
- PerkShop version:
- Dedicated server or local/private game:

## What happened?

Describe the issue.

## Steps to reproduce

1.
2.
3.

## Expected behavior

Describe what should have happened.

## Logs

Paste relevant BepInEx log lines.
