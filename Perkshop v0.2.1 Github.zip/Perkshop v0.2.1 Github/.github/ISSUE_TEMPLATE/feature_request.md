---
name: Feature request
about: Suggest an improvement
title: "[Feature]: "
labels: enhancement
assignees: ""
---

## Summary

Describe the feature.

## Use case

Why is it useful?

## Proposed command/config behavior

If applicable, include command examples or config examples.
